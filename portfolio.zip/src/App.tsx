// App.tsx
import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Hero from "./components/Hero";
import { AboutMe } from "./components/AboutMe";
import { Dashboard } from "./components/Dashboard";
import ControlHub from "./pages/ControlHub";
import { Projects } from "./components/Projects";
import { Skills } from "./components/Skills";
import { LabNotebook } from "./components/LabNotebook";
import { ContactTerminal } from "./components/ContactTerminal";



function HomePage() {
  return (
    <>
      <div className="particles"></div>
      <div className="circuit-overlay"></div>
      <div className="robot-silhouette"></div>

      
      <Hero />
      <AboutMe />
      <Dashboard />
      <Projects />
      <Skills />
      <LabNotebook />
      <ContactTerminal />
    </>
  );
}

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/control-hub" element={<ControlHub />} />
      </Routes>
    </Router>
  );
}
