import React from "react";
import { Link } from "react-router-dom";
import "../styles/dashboard.css";

export const Dashboard: React.FC = () => {
  const modules = [
    { name: "Vision System", route: "/vision-system" },
    { name: "Servo Control", route: "/servo-control" },
    { name: "Voice System", route: "/voice-system" },
    { name: "Power System", route: "/power-system" },
    { name: "Network System", route: "/network-system" },
  ];

  return (
    <section className="dashboard-section" id="dashboard">
      <h2 className="section-title">Robot Control Dashboard</h2>

      <div className="modules-grid">
        {modules.map((mod) => (
          <Link key={mod.name} to={mod.route} className="module-card neon-border">
            <h3>{mod.name}</h3>
          </Link>
        ))}
      </div>
    </section>
  );
}
