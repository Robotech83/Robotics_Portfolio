import "../styles/aboutme.css";

export function AboutMe() {
  return (
    <section className="aboutme-section" id="about">
      <div className="aboutme-card">

        <h2 className="aboutme-title">About Me</h2>

        <p className="aboutme-text">
          I’m a robotics developer who builds humanoid systems, computer vision tools,
          and custom control dashboards. I specialize in Python, Linux, Arduino,
          and real-time robotic systems. I love creating machines that can see,
          move, and interact with the world.
        </p>

      </div>
    </section>
  );
}
