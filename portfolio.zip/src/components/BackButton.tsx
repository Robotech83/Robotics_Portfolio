export function BackButton() {
  return (
    <button
      onClick={() => window.history.back()}
      className="back-btn"
    >
      ← Back
    </button>
  );
}
