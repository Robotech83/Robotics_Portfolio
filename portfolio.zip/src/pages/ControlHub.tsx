import React from "react";

import { BackButton } from "../components/BackButton";

import "../styles/controlhub.css";

// TODO: Replace "inmoov.glb" with your actual Blender-exported robot model
export default function ControlHub() {
  return (
       
    <section className="controlhub-section">
      <BackButton />
      <h2 className="controlhub-title">3D InMoov Control Hub</h2>

    

      <p className="controlhub-instruction">
        Use mouse to rotate/zoom. Sliders and controls for servos will go here.
      </p>
    </section>
  );
}
